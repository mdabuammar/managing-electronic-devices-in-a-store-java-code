
package Electronics;

public class retail2 {
    String device;
    int price;
    String date;
    int quantity;
    retail2(String device,int price,String date, int quantity)
    {
        this.device=device;
        this.price=price;
        this.date=date;
        if (quantity > 3) {
            System.out.println("Quantity Max is 3.");
            this.quantity = 3; } 
        else {
            this.quantity = quantity;
        }
        
    }
      int Calculatefinalprice(){
        return price * quantity;
        
    }
   void display() {
        System.out.println(device + " " + price + " " + date + " " + quantity);
    }
}
